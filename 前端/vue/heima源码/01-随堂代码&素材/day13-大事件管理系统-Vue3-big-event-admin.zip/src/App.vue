<script setup></script>

<template>
  <div>
    <!-- App.vue只需要留一个路由出口 router-view即可 -->
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
