<template>
  <page-container title="文章管理">
    <template #extra>
      <el-button>添加文章</el-button>
    </template>
    主体部分，是表格 + 分页
  </page-container>
</template>

<style lang="scss" scoped></style>
