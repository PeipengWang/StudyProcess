<!-- <script>
export default {
  name: 'RegisterIndex'
}
</script> -->

<script setup>
defineOptions({
  name: 'RegisterIndex'
})
</script>

<template>
<div>
  我是注册页
</div>
</template>



